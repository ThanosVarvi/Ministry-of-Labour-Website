-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 19, 2021 at 02:29 AM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 8.0.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ypakp_database`
--

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(7) NOT NULL,
  `name` text CHARACTER SET utf8 COLLATE utf8_unicode_nopad_ci NOT NULL,
  `surname` text CHARACTER SET utf8 COLLATE utf8_unicode_nopad_ci NOT NULL,
  `username` text CHARACTER SET utf8 COLLATE utf8_unicode_nopad_ci NOT NULL,
  `password` text NOT NULL,
  `email` text NOT NULL,
  `persona` text NOT NULL,
  `company_AFM` int(11) DEFAULT NULL,
  `employer_AFM` int(11) DEFAULT NULL,
  `start_suspension` date DEFAULT NULL,
  `end_suspension` date DEFAULT NULL,
  `start_remote` date DEFAULT NULL,
  `end_remote` date DEFAULT NULL,
  `special_leave` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `surname`, `username`, `password`, `email`, `persona`, `company_AFM`, `employer_AFM`, `start_suspension`, `end_suspension`, `start_remote`, `end_remote`, `special_leave`) VALUES
(1, 'Θεόδωρος', 'Μπαρτσώκας', 'theo', 'bar', 'sdi1700096@di.uoa.gr', 'employer', 123456789, NULL, NULL, NULL, NULL, NULL, NULL),
(2, 'Αθανάσιος', 'Βαρβιτσιώτης', 'athan', 'varv', 'sdi1600016@di.uoa.gr', 'employee', NULL, 1, '0000-00-00', NULL, NULL, NULL, NULL),
(3, 'Φανούριος', 'Δανιήλ', 'fan', 'dan', 'sdi1600041@di.uoa.gr', 'None', NULL, NULL, NULL, NULL, NULL, NULL, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
